//
//  ResultsTableCell.swift
//  MyMedicine
//
//  Created by Fernando H M Bastos on 8/26/15.
//  Copyright (c) 2015 MedCare. All rights reserved.
//

import UIKit

class ResultsTableViewCell: UITableViewCell{

    @IBOutlet weak var resutLabel: UILabel!
    
    
}
